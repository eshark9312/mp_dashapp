# -*- coding: utf-8 -*-
APP_JSON = 'application/json'
APP_MSGPACK = 'application/msgpack'
