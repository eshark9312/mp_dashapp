# -*- coding: utf-8 -*-
# TODO: remove this module entirely.
from collections.abc import Mapping  # noqa: F401
from functools import wraps  # noqa: F401
from inspect import getfullargspec as get_function_spec  # noqa: F401
