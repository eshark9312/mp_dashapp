from typing import List, Optional
from pydantic import BaseModel, Field


class ElasticityData(BaseModel):
    """
    Elastic tensors and associated information.
    """

    k_voigt: Optional[float] = Field(
        None,
        description="Voigt average of the bulk modulus in GPa.",
    )

    k_reuss: Optional[float] = Field(
        None,
        description="Reuss average of the bulk modulus in GPa.",
    )

    k_vrh: Optional[float] = Field(
        None,
        description="Voigt-Reuss-Hill average of the bulk modulus in GPa.",
    )

    g_voigt: Optional[float] = Field(
        None,
        description="Voigt average of the shear modulus in GPa.",
    )

    g_reuss: Optional[float] = Field(
        None,
        description="Reuss average of the shear modulus in GPa.",
    )

    g_vrh: Optional[float] = Field(
        None,
        description="Voigt-Reuss-Hill average of the shear modulus in GPa.",
    )

    universal_anisotropy: Optional[float] = Field(
        None,
        description="Elastic anisotropy.",
    )

    homogeneous_poisson: Optional[float] = Field(
        None,
        description="Poisson's ratio.",
    )

    elastic_tensor: Optional[List[List[float]]] = Field(
        None,
        description="Stiffness tensor in GPa.",
    )

    compliance_tensor: Optional[List[List[float]]] = Field(
        None,
        description="Compliance tensor in 10^(-12)/Pa.",
    )


class ElasticityDoc(BaseModel):
    """
    Model for a document containing elasticity data
    """

    pretty_formula: Optional[str] = Field(
        None,
        description="Cleaned representation of the material formula",
    )

    chemsys: Optional[str] = Field(
        None,
        description="Dash-delimited string of elements in the material.",
    )

    elasticity: Optional[ElasticityData] = Field(
        None,
        description="Elasticity data for the material.",
    )

    task_id: Optional[str] = Field(
        None,
        description="The Materials Project ID of the material. This comes in the form: mp-******.",
    )
