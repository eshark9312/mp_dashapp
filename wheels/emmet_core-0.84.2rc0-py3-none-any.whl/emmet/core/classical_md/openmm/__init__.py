from emmet.core.classical_md.openmm.tasks import (
    Calculation,
    CalculationInput,
    CalculationOutput,
    OpenMMTaskDocument,
)
