def time_import():
    import pint  # noqa: F401
