Main authors:

* David Eppstein

  - wrote the original LaTeX codec as a recipe on ActiveState
    http://code.activestate.com/recipes/252124-latex-codec/

* Peter Tröger

  - wrote the original latexcodec package, which contained a simple
    but very effective LaTeX encoder

* Matthias Troffaes (matthias.troffaes@gmail.com)

  - wrote the lexer

  - integrated codec with the lexer for a simpler and more robust
    design

  - various bugfixes

Contributors:

* Michael Radziej

* Philipp Spitzer
